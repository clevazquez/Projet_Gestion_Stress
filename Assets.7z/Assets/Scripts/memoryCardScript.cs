using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class memoryCardScript : MonoBehaviour
{
    public Sprite[] faces;
    public Sprite back;
    private GameObject memoryControl;
    public bool matched = false;

    private SpriteRenderer spriteRenderer;
    [HideInInspector]
    public int indexFace;

    void Awake() {
        //Initialisation du SpriteRenderer
        spriteRenderer = GetComponent<SpriteRenderer>();
        memoryControl = GameObject.Find("MemoryControl");
    }

    public void OnMouseDown()
    {
        if (matched == false)
        {
            if (spriteRenderer.sprite == back)
            {
                if (memoryControl.GetComponent<memoryControl>().twoCardUp() == false)
                {
                    spriteRenderer.sprite = faces[indexFace];
                    memoryControl.GetComponent<memoryControl>().AddVisibleFace(indexFace);
                    matched = memoryControl.GetComponent<memoryControl>().CheckMatch(indexFace);
                }
            }
            else
            {
                spriteRenderer.sprite = back;
                memoryControl.GetComponent<memoryControl>().RemoveVisibleFace(this.indexFace);
            }
        }
    }

}
