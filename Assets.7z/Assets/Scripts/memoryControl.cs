using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class memoryControl : MonoBehaviour
{
    public GameObject memoryCard;
    private List<int> facesIndexes = new List<int> { 0, 1, 2, 3, 0, 1, 2, 3 };

    public static System.Random rnd = new System.Random();
    public int intShuffle = 0;
    private int[] visibleFaces = { -1, -2 };

    // Start is called before the first frame update
    void Start()
    {
        int sizeMaxStart = facesIndexes.Count;
        float xPos = -2.5f;
        float yPos = 2.5f;

        for(int i = 0; i < 7; i++)
        {
            intShuffle = rnd.Next(0, (facesIndexes.Count));
            GameObject temp = Instantiate(memoryCard, new Vector3(xPos, yPos, 0), Quaternion.identity);
            // Face de la carte tirer au hasard          
            temp.GetComponent<memoryCardScript>().indexFace = facesIndexes[intShuffle];
            facesIndexes.Remove(facesIndexes[intShuffle]);
            xPos += 5f;
            if(i == sizeMaxStart/2 - 2)
            {
                xPos = -7.5f;
                yPos = -2.5f;
            }
        }
        // Face al�atoire de la premi�re carte
        memoryCard.GetComponent<memoryCardScript>().indexFace = facesIndexes[0];
    }

    public bool twoCardUp()
    {
        bool res = false;
        if (visibleFaces[0] >= 0 && visibleFaces[1] >= 0)
        {
            res = true;
        }
        return res;
    }

    public void AddVisibleFace(int index)
    {
        if (visibleFaces[0] == -1)
        {
            visibleFaces[0] = index;
        }
        else if (visibleFaces[1] == -2)
        {
            visibleFaces[1] = index;
        }
    }

    public bool CheckMatch(int index)
    {
        bool success = false;
        if (visibleFaces[0] == visibleFaces[1])
        {
            visibleFaces[0] = -1;
            visibleFaces[1] = -2;
            success = true;
        }
        return success;
    }

    public void RemoveVisibleFace(int index)
    {
        if (visibleFaces[0] == index)
        {
            visibleFaces[0] = -1;
        }
        else if (visibleFaces[1] == index)
        {
            visibleFaces[1] = -2;
        }
    }
}
